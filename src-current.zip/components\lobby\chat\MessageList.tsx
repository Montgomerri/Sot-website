"use client";

import MessageBubble from "./MessageBubble";
import { LobbyMessage } from "@/types/lobby";


interface Props {
  messages: LobbyMessage[];
}


export default function MessageList({
  messages,
}: Props) {


  if(messages.length === 0){

    return (

      <div
        className="
          flex
          flex-1
          items-center
          justify-center
          text-gray-400
        "
      >

        No messages yet

      </div>

    );

  }



  return (

    <div
      className="
        flex-1
        overflow-y-auto
        py-4
      "
    >

      {
        messages.map((message)=>(

          <MessageBubble

            key={message.id}

            name={
              message.profiles?.full_name 
              ?? "User"
            }

            message={
              message.content
            }

            time={
              new Date(
                message.created_at
              ).toLocaleTimeString(
                [],
                {
                  hour:"2-digit",
                  minute:"2-digit"
                }
              )
            }

          />

        ))
      }


    </div>

  );

}