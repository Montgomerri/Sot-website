import ServerSidebar from "./ServerSidebar";
import ChannelSidebar from "./ChannelSidebar";
import ChatArea from "./ChatArea";
import MemberList from "./MemberList";

export default function LobbyLayout() {
  return (
    <div className="flex h-[calc(100vh-50px)] bg-slate-50">

      <ServerSidebar />

      <ChannelSidebar />

      <ChatArea />

      <MemberList />

    </div>
  );
}