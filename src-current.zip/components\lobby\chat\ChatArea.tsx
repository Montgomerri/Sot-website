"use client";


import ChatHeader from "./ChatHeader";
import MessageList from "./MessageList";
import MessageInput from "./MessageInput";

import { LobbyMessage } from "@/types/lobby";


interface Props {

  messages: LobbyMessage[];

  sendMessage: (
    content:string
  ) => Promise<void>;

}



export default function ChatArea({
  messages,
  sendMessage,
}:Props){


  return (

    <main
      className="
        flex
        flex-1
        flex-col
        bg-white
      "
    >


      <ChatHeader />


      <MessageList
        messages={messages}
      />


      <MessageInput
        sendMessage={sendMessage}
      />


    </main>

  );

}