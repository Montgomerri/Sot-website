export interface LobbyMessage {
  id: string;
  user_id: string;
  content: string;
  created_at: string;
  image_url?: string | null;

  profiles?: {
    full_name: string | null;
    avatar_url: string | null;
  } | null;
}