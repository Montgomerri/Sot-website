"use client";

import { useEffect, useState } from "react";

import { createClient } from "@/lib/supabase/client";

import {
  getLobbyMessages,
  sendLobbyMessage,
} from "@/services/lobby/lobby";

import { LobbyMessage } from "@/types/lobby";

export default function useLobby() {
  const [messages, setMessages] = useState<LobbyMessage[]>([]);

  useEffect(() => {
    let channel: ReturnType<ReturnType<typeof createClient>["channel"]> | null =
      null;

    async function setupRealtime() {
      const supabase = createClient();

      // Load existing messages
      const data = await getLobbyMessages();

      setMessages(
  data as unknown as LobbyMessage[]
);

      // Get the currently authenticated session
      const {
        data: { session },
      } = await supabase.auth.getSession();

      console.log("SESSION:", session);

      if (!session) {
        console.error("No authenticated session found.");
        return;
      }

      // Explicitly give the Realtime client the user's JWT
      supabase.realtime.setAuth(session.access_token);

      console.log("Realtime auth set.");

      // Create realtime channel
      channel = supabase
        .channel("lobby-room")
        .on(
          "postgres_changes",
          {
            event: "INSERT",
            schema: "public",
            table: "lobby_messages",
          },
          (payload) => {
            console.log("==============");
            console.log("Realtime status: INSERT received");
            console.log("Realtime payload:", payload);
            console.log("payload.new:", payload.new);
            console.log("==============");

            const newMessage = payload.new as LobbyMessage;

            setMessages((current) => {
              // Prevent duplicates
              if (current.some((message) => message.id === newMessage.id)) {
                return current;
              }

              return [...current, newMessage];
            });
          }
        )
        .subscribe((status, error) => {
          console.log("Realtime subscription status:", status);

          if (error) {
            console.error("Realtime subscription error:", error);
          }
        });
    }

    setupRealtime();

    return () => {
      if (channel) {
        const supabase = createClient();
        supabase.removeChannel(channel);
      }
    };
  }, []);

  async function sendMessage(
  content: string,
  imageUrl?: string | null
) {
  await sendLobbyMessage(
    content,
    imageUrl
  );
}

  return {
    messages,
    sendMessage,
  };
}