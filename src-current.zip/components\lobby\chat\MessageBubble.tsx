import {
  MoreHorizontal,
} from "lucide-react";

interface Props {
  name: string;
  message: string;
  time: string;
  imageUrl?: string | null;
  avatar?: string;
}

export default function MessageBubble({
  name,
  message,
  time,
  imageUrl,
}: Props) {
  return (
    <div
      className="
        group
        flex
        gap-4
        px-6
        py-4
        transition
        hover:bg-blue-50/50
      "
    >
      {/* Avatar */}

      <div
        className="
          flex
          h-11
          w-11
          shrink-0
          items-center
          justify-center
          rounded-full
          bg-blue-500
          font-semibold
          text-white
        "
      >
        {name.charAt(0).toUpperCase()}
      </div>

      {/* Message */}

      <div className="flex-1">
        <div
          className="
            flex
            items-center
            gap-3
          "
        >
          <h4
            className="
              font-semibold
              text-gray-900
            "
          >
            {name}
          </h4>

          <span
            className="
              text-xs
              text-gray-400
            "
          >
            {time}
          </span>

          <button
            className="
              ml-auto
              hidden
              text-gray-400
              group-hover:block
            "
          >
            <MoreHorizontal size={18} />
          </button>
        </div>

        {/* Text */}

        {message && (
          <p
            className="
              mt-1
              text-sm
              leading-6
              text-gray-600
            "
          >
            {message}
          </p>
        )}

        {/* Image */}

        {imageUrl && (
          <div className="mt-3">
            <img
              src={imageUrl}
              alt="Uploaded image"
              className="
                max-h-96
                max-w-md
                rounded-xl
                border
                border-gray-200
                object-cover
              "
            />
          </div>
        )}
      </div>
    </div>
  );
}