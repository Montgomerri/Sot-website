import { createClient } from "@/lib/supabase/client";

export async function getLobbyMessages() {
  const supabase = createClient();

  const {
    data,
    error,
  } = await supabase
    .from("lobby_messages")
    .select(`
      id,
      user_id,
      content,
      created_at,
      image_url,
      profiles (
        full_name,
        avatar_url
      )
    `)
    .order("created_at", {
      ascending: true,
    });

  if (error) {
    console.error(
      "Failed to load lobby messages:",
      error
    );

    return [];
  }

  return data ?? [];
}

export async function sendLobbyMessage(
  content: string,
  imageUrl?: string | null
) {
  const supabase = createClient();

  const {
    data: {
      user,
    },
  } = await supabase.auth.getUser();

  if (!user) {
    throw new Error(
      "User not authenticated"
    );
  }

  const {
    error,
  } = await supabase
    .from("lobby_messages")
    .insert({
      user_id: user.id,
      content,
      image_url: imageUrl ?? null,
    });

  if (error) {
    console.error(
      "Failed to send lobby message:",
      error
    );

    throw error;
  }
}