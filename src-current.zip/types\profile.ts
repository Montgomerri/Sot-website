export interface Profile {
  id: string;
  full_name: string | null;
  avatar_url: string | null;
  reputation: number | null;
  department: string | null;
  bio: string | null;
  created_at: string;
}