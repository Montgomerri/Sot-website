export default function ChatArea(){

return(

<main
className="
flex-1
flex
flex-col
bg-white
"
>

<div
className="
border-b
p-5
font-semibold
"
>
# general
</div>


<div
className="
flex-1
flex
items-center
justify-center
text-slate-400
"
>
No messages yet
</div>


</main>

)

}